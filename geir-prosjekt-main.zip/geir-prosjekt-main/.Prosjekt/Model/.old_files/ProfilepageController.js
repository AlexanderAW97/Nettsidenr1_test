function updateProgressbar1() {
  updateBars();
}

function updateProgressbar2() {
  updateBars();
}

function updateProgressbar3() {
  updateBars();
}
