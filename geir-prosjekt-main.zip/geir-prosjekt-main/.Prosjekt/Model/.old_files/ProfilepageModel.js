/* let progressbar1 = 0;
let progressbar2 = 0;
let progressbar3 = 0;
 */
