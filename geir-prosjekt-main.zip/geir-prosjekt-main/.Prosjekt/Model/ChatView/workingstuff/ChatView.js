function updateChatPageView(){
let html = "";

let personer =

`<div>hei</div>`

    
return html
}

//åpner meldingsboks, pluss setter feltet med innkommende mld til lest status/endrer CSS til annen farge
/*  

function åpneChat(){
    
      let html = '';
      let meldingsTekst = model.chatMessages[0].messageContent;
      for (let i = 0; i < model.chatMessages.messageContent.length; i++)
      html += /*html*/ `
      